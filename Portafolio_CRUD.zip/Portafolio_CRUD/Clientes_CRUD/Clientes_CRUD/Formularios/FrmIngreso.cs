﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using Clientes_CRUD.Clases;

namespace Clientes_CRUD.Formularios
{
    public partial class FrmIngreso : Form
    {

        Conexion con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;
        int count;


        public FrmIngreso()
        {
            InitializeComponent();
            con = new Conexion();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("SELECT * FROM usuarios where usuario = '" + txtUsuario.Text +
                "' and password = '" + txtPassword.Text +"'", con.abrirConexion());

            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                Form1 frm = new Form1();
                frm.Show();
                this.Close();
            }
            else
            {
                count++;
                MessageBox.Show("Usuario o contraseña incorrectos " + count + " intento");
            }

            if (count == 3)
            {
                this.Close();
                MessageBox.Show("Demasiados intentos, cerramos el programa por tu seguridad");
            }

        }

        private void btnSalirIngreso_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
