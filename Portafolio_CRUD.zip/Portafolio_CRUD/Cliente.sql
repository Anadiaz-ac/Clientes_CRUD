CREATE DATABASE cliente;


create table cliente(
	Cedula verchar(11) primary key,
	Nombre varchar(60),
	Apellidos varchar(80),
	Celular varchar (15),
	Correo varchar (50)
)


create table usuarios(
	usuario varchar(20),
	password varchar(10)
)