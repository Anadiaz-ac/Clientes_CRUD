﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace Clientes_CRUD.Clases
{
    internal class Conexion
    {
        //static private String CadenaConexion= @"Data Source=(LocalBD)MSSQLLocalDB;AttachDbFilename=C:\Users\anama\OneDrive\Documentos\C#\Portafolio_CRUD"
        private SqlConnection CadenaConexion = new SqlConnection("Integrated Security=SSPI;Persist Security Info=False;Initial Catalog=cliente;Data Source=DESKTOP-IN3GB3V");


        public SqlConnection abrirConexion()
        {
            if (CadenaConexion.State == ConnectionState.Closed)
            {
                CadenaConexion.Open();
            }
            return CadenaConexion;
        }

        public SqlConnection cerrarConexion()
        {
            if(CadenaConexion.State == ConnectionState.Open)
            {
                CadenaConexion.Close();
            }
            return CadenaConexion;
        }


    }
}
