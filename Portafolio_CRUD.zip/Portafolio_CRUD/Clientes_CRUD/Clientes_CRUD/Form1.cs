﻿using Clientes_CRUD.Clases;
using Clientes_CRUD.Formularios;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Clientes_CRUD
{
    public partial class Form1 : Form
    {

        Conexion con;
        SqlCommand cmd;
        SqlDataAdapter da;
        DataTable dt;

        public Form1()
        {
            InitializeComponent();
            con = new Conexion();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'clienteDataSet.cliente' Puede moverla o quitarla según sea necesario.
            this.clienteTableAdapter.Fill(this.clienteDataSet.cliente);

        }

        private void txtSalir_Click(object sender, EventArgs e)
        {
            FrmIngreso frm = new FrmIngreso();
            frm.Show();
            this.Close();
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            //cmd = new SqlCommand("SELECT * FROM cliente WHERE Cedula = '" + txtCedula.Text + "'", con.abrirConexion());
            //da = new SqlDataAdapter(cmd);
            //dt = new DataTable();
            //da.Fill(dt);

            //if (cmd.ExecuteNonQuery() == 1)
            //{
            //    MessageBox.Show("El cliente con cedula "+ txtCedula.Text + " ya existe!");
            //}
            //else
            //{

            if(txtCedula.Text==string.Empty || txtNombre.Text == string.Empty || txtApellido.Text == string.Empty || txtCelular.Text == string.Empty || txtCorreo.Text == string.Empty)
            {
                MessageBox.Show("Se debe ingresar todos los datos");
            }
            else
            {
                cmd = new SqlCommand("INSERT INTO cliente VALUES('" + txtCedula.Text + "','" + txtNombre.Text + "','" + txtApellido.Text + "','" + txtCelular.Text + "','" + txtCorreo.Text + "')", con.abrirConexion());
                cmd.ExecuteNonQuery();
                MessageBox.Show("¡Se guardo el cliente exitosamente!");
                ActualizarGrid();
                limpiar();
            }

            //}
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            if (txtCedula.Text == string.Empty)
            {
                MessageBox.Show("Se debe ingresar la cedula para eliminar el cliente");
            }
            else
            {
                cmd = new SqlCommand("DELETE FROM cliente WHERE Cedula = '" + txtCedula.Text + "'", con.abrirConexion());
                cmd.ExecuteNonQuery();
                MessageBox.Show("¡Se eliminó  el cliente exitosamente!");
                ActualizarGrid();
                limpiar();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        void ActualizarGrid()
        {
            cmd = new SqlCommand("SELECT * FROM cliente", con.abrirConexion());
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;
        }


        void limpiar()
        {
            txtCedula.Clear();
            txtNombre.Clear();
            txtApellido.Clear();
            txtCelular.Clear();
            txtCorreo.Clear();
        }

        private void btnBuscarCliente_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("SELECT * FROM cliente WHERE Cedula='"+txtBuscarCliente.Text+"'", con.abrirConexion());
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;
        }

        private void btnLimpiarFiltro_Click(object sender, EventArgs e)
        {
            cmd = new SqlCommand("SELECT * FROM cliente", con.abrirConexion());
            da = new SqlDataAdapter(cmd);
            dt = new DataTable();
            da.Fill(dt);

            dataGridView1.DataSource = dt;

            txtBuscarCliente.Clear();
        }

        private void Actualizar_Click(object sender, EventArgs e)
        {

            cmd = new SqlCommand("UPDATE cliente SET Nombre='" + txtNombre.Text + "', Apellidos='" + txtApellido.Text+"', Celular='" + txtCelular.Text + "', Correo='" + txtCorreo.Text + "' WHERE Cedula='" + txtCedula.Text + "'", con.abrirConexion());
            cmd.ExecuteNonQuery();
            MessageBox.Show("¡Se actualizó el cliente exitosamente!");
            ActualizarGrid();
            limpiar();

        }
    }
}
